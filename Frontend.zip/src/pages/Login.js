import React from "react";
import { Link } from "react-router-dom";
import axios from 'axios';

async function handleLoginWithGoogle() {
  try {
    const response = await fetch('http://localhost:5000/api/auth/google'); // Your backend endpoint
    const data = await response.json();
    window.location.href = data.authUrl; // Assuming authUrl is returned in JSON response
  } catch (error) {
    console.error('Error initiating login:', error);
  }
}

function Login() {
  return (
    <>
      <div className="container-xxl mt-5">
        <div className="authentication-wrapper authentication-basic container-p-y">
          <div className="authentication-inner">
            <div className="row justify-content-center mt-5">
              <div className="card col-md-4 py-5">
                <div className="card-body">
                  <div className="app-brand justify-content-center">
                    <a href="index.html" className="app-brand-link gap-2">
                      <span className="app-brand-text demo text-body fw-bolder">
                       Smart Education System
                      </span>
                    </a>
                  </div>

                  <form
                    id="formAuthentication"
                    className="mb-3 mt-5"
                    action="index.html"
                    method="POST"
                  >
                    <div className="mb-3">
                      <label for="email" className="form-label">
                        Email 
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        id="email"
                        name="email-username"
                        placeholder="Enter your email"
                        autofocus
                      />
                    </div>
                    <div className="mb-3 form-password-toggle">
                      <div className="d-flex justify-content-between">
                        <label className="form-label" for="password">
                          Password
                        </label>
                       
                      </div>
                      <div className="input-group input-group-merge">
                        <input
                          type="password"
                          id="password"
                          className="form-control"
                          name="password"
                          placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;"
                          aria-describedby="password"
                        />
                        <span className="input-group-text cursor-pointer">
                          <i className="bx bx-hide"></i>
                        </span>
                      </div>
                    </div>
                    
                    <div className="mb-3">
                      <button
                        className="btn btn-primary d-grid w-100"
                        type="submit"
                      >
                        Sign in
                      </button>
                    </div>
                  </form>

                  <p className="text-center">
                    <Link to="/register">
                      <span>Create an account</span>
                    </Link>
                    {/* <div className="mb-3 ">
                      <button className="btn btn-primary d-grid w-100" onClick={handleLoginWithGoogle}>
                        Login with Google
                      </button>
                    </div> */}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Login;
