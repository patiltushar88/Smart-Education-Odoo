import { BrowserRouter, Routes, Route } from "react-router-dom";
import './App.css';
// import Admin from './componets/admin/Admin.js';
// import Teacher from './componets/admin/Teacher_List.js';
// import Students from './componets/admin/Students_List.js';
import Dashboard from './componets/student/Dashboard.js';
import Courselist from './componets/student/Courselist.js';
import Course from './componets/student/Course.js';
import Games from './componets/student/Games.js';
import Games2 from './componets/student/Games2.js';
import Leadrborad from './componets/student/Leadrborad.js';
import Assignments from './componets/student/Assignments.js';
import Teacher_Dashboard from './componets/teacher/Teacher_Dashboard.js';
import View from './componets/teacher/View.js';
import Teacher_Course from './componets/teacher/Teacher_Course.js';
import Teacher_Assignment from './componets/teacher/Teacher_Assign.js';
import Login from './pages/Login.js';
import Register from './pages/Register.js';
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/register" element={<Register />} />
        
        {/* <Route path="/admin/dashboard" element={<Admin />} />
        <Route path="/admin/teacherslist" element={<Teacher />} />
        <Route path="/admin/studentslist" element={<Students />} /> */}


        <Route path="/teacher/teacher_dashboard" element={<Teacher_Dashboard />} />
        <Route path="/teacher/teachcourse" element={<Teacher_Course />} />
        <Route path="/teacher/teachass" element={<Teacher_Assignment />} />
        <Route path="/teacher/view" element={<View />} />

        <Route path="/student/dashboard" element={<Dashboard />} />
        <Route path="/student/courselist" element={<Courselist />} />
        <Route path="/student/courses" element={<Course />} />
        <Route path="/student/assignments" element={<Assignments />} />
        <Route path="/student/leadrborad" element={<Leadrborad />} />
        <Route path="/student/games" element={<Games />} />
        <Route path="/student/games2" element={<Games2 />} />

      </Routes>
    </BrowserRouter>
  );
}

export default App;
