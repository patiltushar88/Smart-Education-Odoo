import React from "react";
import Footer from "../inc/footer.js";
import Header from "./inc/header.js";
import Navbar from "./inc/Navbar.js";

function Teacher_Assign() {
  return (
    <div>
      <div>
        <div class="layout-wrapper layout-content-navbar">
          <div class="layout-container">
            <Navbar />

            <div class="layout-page">
              <Header />
              <div className="container-xxl flex-grow-1 container-p-y">
                <div className="row justify-content-center">
                  {/* <div className="col-lg-11 mb-4 order-0"> */}
                  <div class="col-md-10">
                    <div class="card mb-4">
                      <h5 class="card-header">Add Assignment</h5>
                      <div class="card-body">
                        <div class="form-floating py-2">
                          <input
                            type="text"
                            class="form-control"
                            id="courseName"
                            placeholder="Assignment Name"
                            aria-describedby="floatingInputHelp"
                          />
                          <label for="floatingInput">Assignment Name</label>
                        </div>
                        <div class="form-floating py-2">
                          <input
                            type="text"
                            class="form-control"
                            id="assDescription"
                            placeholder="Course Description"
                            aria-describedby="floatingInputHelp"
                          />
                          <label for="floatingInput">Assignment Description</label>
                        </div>
                        <div class="form-floating py-2">
                          <input
                            type="url"
                            class="form-control"
                            id="assLink"
                            placeholder="courseVideo"
                            aria-describedby="floatingInputHelp"
                          />
                          <label for="floatingInput">Assignment Link</label>
                        </div>
                        <div class="form">
                          <button
                            class="form-control btn-primary"
                            id="floatingInput"
                            placeholder="John Doe"
                            aria-describedby="floatingInputHelp"
                          >
                            Submit
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
           
          </div>
          
        </div>
        <div>
          
        </div>
        <Footer />
      </div>
    </div>
  );
}

export default Teacher_Assign;
