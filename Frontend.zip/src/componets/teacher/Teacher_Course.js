import React from "react";
import Footer from "../inc/footer.js";
import Header from "./inc/header.js";
import Navbar from "./inc/Navbar.js";

const Teacher_Course = () => {


  
  return (
    <div>
      <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
          <Navbar />

          <div class="layout-page">
            <Header />
            <div className="container-xxl flex-grow-1 container-p-y">
            <div className="row justify-content-center">
              {/* <div className="col-lg-11 mb-4 order-0"> */}
              <div class="col-md-10">
                  <div class="card mb-4">
                    {/* <h5 class="card-header">Add Course</h5> <button onClick={view}>View Details</button> */}
                    <div class="card-body">
                      <div class="form-floating py-2">
                        <input type="text" class="form-control" id="courseName" placeholder="Course Name" aria-describedby="floatingInputHelp"/>
                        <label for="floatingInput">Course Name</label>
                        
                      </div>
                      <div class="form-floating py-2">
                        <input type="text" class="form-control" id="courseDes" placeholder="Course Description" aria-describedby="floatingInputHelp"/>
                        <label for="floatingInput">Course Description</label>
                        
                      </div>
                      <div class="form-floating py-2">
                        <input type="file" class="form-control" id="courseVideo" placeholder="courseVideo" aria-describedby="floatingInputHelp"/>
                        <label for="floatingInput">Video</label>
                        
                      </div>
                      <div class="form">
                        <button class="form-control btn-primary" id="floatingInput" placeholder="John Doe" aria-describedby="floatingInputHelp">Submit</button>
                        
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            </div>
          {/* </div> */}
        </div>
        <div class="layout-overlay layout-menu-toggle"></div>
      </div>
      <Footer />
      <div class="modal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Modal title</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p>Modal body text goes here.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>


    </div>
  );
};

export default Teacher_Course;
