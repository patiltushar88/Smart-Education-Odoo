import React from 'react'
import Footer from '../inc/footer.js'
import Header from '../inc/header.js'
import { Link } from 'react-router-dom';
import Navbar from '../inc/Navbar.js'
function Courselist() {
  return (
    <>
    
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
     
<Navbar/>
     
   
        <div class="layout-page">
        

       <Header/>
       <div class="container-xxl flex-grow-1 container-p-y">
              <div class="row">
                <div class="col-lg-11 mb-4 order-0">
    <div class="row mb-5">
        <h2>Course List</h2>
                {/* <div class="col-md-6 col-lg-4"> */}
                  <div class="ms-3 card mb-3">
                    <div class="card-body">
                    <tr className='row'>
                      <th class="col-md-4 card-title">Course Name</th>
                      <th class="col-md-4 card-title">Course Description</th>
                      <th class="col-md-4 card-title">View Course</th>
                    </tr>
                    <tr className='row'>
                      <td class="col-md-4 card-title">English</td>
                      <td class="col-md-4 card-title">The students will be dealing with more formal skills of writing, grammar</td>
                      <td className="col-md-4 card-title">
  <a href="https://youtube.com/playlist?list=PLVG8tGc7EksawGCL1geLbLOuQPQxmx8LL&si=F2S9KqSr7Pl64A_H" className="btn btn-primary" target="_blank">View Course</a>
</td>
                    </tr>
                    <tr className='row'>
                      <td class="col-md-4 card-title">Math</td>
                      <td class="col-md-4 card-title">Mathematics is the science and study of quality, structure, space, and change</td>
                      <td className="col-md-4 card-title">
  <a href="https://youtube.com/playlist?list=PLfhSyUAzCWXoKZImlV7sbw5lD0Yw-Pngq&si=M5kjpxRnQ1XBHIiV" className="btn btn-primary" target="_blank">View Course</a>
</td>
                    </tr>
              
                    </div>

                </div>
              
              </div>
              </div>
              </div>
              </div>
              <Footer/>
              </div>
              </div>
              </div>
    </>
  )
}

export default Courselist