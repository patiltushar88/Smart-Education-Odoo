import React from "react";
import Footer from "../inc/footer.js";
import Header from "../inc/header.js";
import { Link } from "react-router-dom";
import Navbar from "../inc/Navbar.js";
function Course() {
  return (
    <>
      <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
          <Navbar />

          <div class="layout-page">
            <Header />
            <div class="container-xxl flex-grow-1 container-p-y">
              <div class="row">
                <div class="col-lg-11 mb-4 order-0">
                <div class="main-container">
      <div class="main">
         
      
         <h1>Math Addition <span> Quiz Game :)</span></h1>

         <div class="main-box">
            <div class="show-anwser"><span id="ans"></span></div>

            <div class="box1">
               <div class="box-col">
                  <input type="textf" id="intext" class="intext11"/>
               </div>

               <div class="add-s">
                  <p>+</p>
               </div>

                <div class="box-col">
                  <input type="textf" id="intext1" class="intext11"/>
               </div>

            </div>

            <div class="box2">
               <input tpye="text" placeholder="Enter Answer" id="intext2"/>
            </div>

     
             <div class="box2">
               <button class="btn" onclick="Game()"> Check Anwser</button>
            </div>
         </div>
      </div>
   </div>

 
                </div>
              </div>
            </div>
            <Footer />
          </div>
        </div>
      </div>
    </>
  );
}

export default Course;
