import React from 'react'
import Footer from '../inc/footer.js'
import Header from '../inc/header.js'
import Navbar from '../inc/Navbar.js'
function Dashboard() {
  return (
    <>
    
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
     
<Navbar/>
     
   
        <div class="layout-page">
        

       <Header/>

         
          <div class="content-wrapper">
           
            <div class="container-xxl flex-grow-1 container-p-y">
              <div class="row">
                <div class="col-lg-8 mb-4 order-0">
                  <div class="card">
                    <div class="d-flex align-items-end row">
                      <div class="col-sm-7">
                        <div class="card-body">
                          <h5 class="card-title text-primary">Congratulations You are successful logged in! 🎉</h5>
                          

                        
                        </div>
                      </div>
                      <div class="col-sm-5 text-center text-sm-left">
                        <div class="card-body pb-0 px-0 px-md-4">
                          <img
                            src="../assets/img/illustrations/man-with-laptop-light.png"
                            height="140"
                            alt="View Badge User"
                            data-app-dark-img="illustrations/man-with-laptop-dark.png"
                            data-app-light-img="illustrations/man-with-laptop-light.png"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
               
             
              </div>
            </div>
         
           <Footer/>
       

            <div class="content-backdrop fade"></div>
          </div>
         
        </div>
      </div>

    
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    
    </>
  )
}

export default Dashboard