import "./Leadrborad.css";
import React from "react";
import Footer from "../inc/footer.js";
import Header from "../inc/header.js";
import { Link } from "react-router-dom";
import Navbar from "../inc/Navbar.js";
function Leadrborad() {
  return (
    <>
      <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
          <Navbar />

          <div class="layout-page">
            <Header />
            <div class="container-xxl flex-grow-1 container-p-y">
              <div class="row">
                <div class="col-lg-12 mb-4 order-0">
                  <main class="col-lg-12">
                    <div id="header">
                      <h3>Ranking</h3>
                      <h3>Levels</h3>
                      <h3>Batch</h3>
                    </div>
                    <div id="leaderboard">
                      <table>
                      <div class="ribbon"></div>

                        <tr>
                          <td class="number">1</td>
                          <td class="name">Lee Taeyong</td>
                          <td class="name">1 Level</td>

                          <td class="points">
                            <img
                              class="gold-medal"
                              src="https://github.com/malunaridev/Challenges-iCodeThis/blob/master/4-leaderboard/assets/gold-medal.png?raw=true"
                              alt="gold medal"
                            />
                          </td>
                        </tr>
                        <tr>
                          <td class="number">2</td>
                          <td class="name">Mark Lee</td>
                          <td class="name">2 Level</td>
                          <td class="points">
                            <img
                              class="gold-medal"
                              src="https://github.com/malunaridev/Challenges-iCodeThis/blob/master/4-leaderboard/assets/gold-medal.png?raw=true"
                              alt="gold medal"
                            />
                          </td>
                        </tr>
                        <tr>
                          <td class="number">3</td>
                          <td class="name">Xiao Dejun</td>
                          <td class="name">2 Level</td>
                          <td class="points">
                            <img
                              class="gold-medal"
                              src="https://github.com/malunaridev/Challenges-iCodeThis/blob/master/4-leaderboard/assets/gold-medal.png?raw=true"
                              alt="gold medal"
                            />
                          </td>
                        </tr>
                        <tr>
                          <td class="number">4</td>
                          <td class="name">Qian Kun</td>
                          <td class="name">3 Level</td>
                          <td class="points">
                            <img
                              class="gold-medal"
                              src="https://github.com/malunaridev/Challenges-iCodeThis/blob/master/4-leaderboard/assets/gold-medal.png?raw=true"
                              alt="gold medal"
                            />
                          </td>
                        </tr>
                        <tr>
                          <td class="number">5</td>
                          <td class="name">Johnny Suh</td>
                          <td class="name">3 Level</td>
                          <td class="points">
                            <img
                              class="gold-medal"
                              src="https://github.com/malunaridev/Challenges-iCodeThis/blob/master/4-leaderboard/assets/gold-medal.png?raw=true"
                              alt="gold medal"
                            />
                          </td>
                        </tr>
                      </table>
                    </div>
                  </main>
                </div>
              </div>
            </div>
            <Footer />
          </div>
        </div>
      </div>
    </>
  );
}

export default Leadrborad;
