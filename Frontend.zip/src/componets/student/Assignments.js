import React from 'react'

import Footer from '../inc/footer.js'
import Header from '../inc/header.js'
import { Link } from 'react-router-dom';
import Navbar from '../inc/Navbar.js'
function Assignments() {
  return (
    <>
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <Navbar />

        <div class="layout-page">
          <Header />
          <div class="container-xxl flex-grow-1 container-p-y">
          <div class="row">
              <div class="col-lg-11 mb-4 order-0">
              <div class="card">
                <h5 class="card-header">View Assignment </h5>
                <div class="table-responsive text-nowrap">
                  <table class="table">
                    <thead>
                      <tr>
                        <th>Assignment Link</th>
                        <th>Assignment Description</th>
                        <th>Assignment Link</th>
                        <th>Status</th>
                      
                      </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                      <tr>
                        <td className='text-dark'><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>Math</strong></td>
                        <td className='text-dark'>Mathematics </td>
                        <td>
                        <td className='text-dark'>
                         Not Found
                        </td>
                        </td>
                        <td><span class="badge bg-label-primary me-1">Active</span></td>
                       
                      </tr>
                      <tr>
                        <td><i class="fab fa-react fa-lg text-info me-3"></i> <strong>English</strong></td>
                        <td>English</td>
                        <td>
                         Not Found
                        </td>
                        <td><span class="badge bg-label-success me-1">Completed</span></td>
                      
                      </tr>
                      {/* <tr>
                        <td><i class="fab fa-vuejs fa-lg text-success me-3"></i> <strong>VueJs Project</strong></td>
                        <td>Trevor Baker</td>
                        <td>
                          {/* <ul class="list-unstyled users-list m-0 avatar-group d-flex align-items-center">
                            <li data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" class="avatar avatar-xs pull-up" title="" data-bs-original-title="Lilian Fuller">
                              <img src="../assets/img/avatars/5.png" alt="Avatar" class="rounded-circle">
                            </li>
                            <li data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" class="avatar avatar-xs pull-up" title="" data-bs-original-title="Sophia Wilkerson">
                              <img src="../assets/img/avatars/6.png" alt="Avatar" class="rounded-circle">
                            </li>
                            <li data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" class="avatar avatar-xs pull-up" title="" data-bs-original-title="Christina Parker">
                              <img src="../assets/img/avatars/7.png" alt="Avatar" class="rounded-circle">
                            </li>
                          </ul> */}
                        {/* </td>
                        <td><span class="badge bg-label-info me-1">Scheduled</span></td>
                        
                      </tr> */}
                                         </tbody>
                  </table>
                </div>
              </div>
              </div>
            </div>
          </div>
          <Footer />
        </div>
      </div>
    </div>
  </>
  )
}

export default Assignments