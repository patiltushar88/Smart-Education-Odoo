import React, { useState, useEffect } from "react";
import Footer from "../inc/footer.js";
import Header from "../inc/header.js";
import Navbar from "../inc/Navbar.js";
import "./Games2.css";

function Games2() {
 // State Variables
 const [secretWord, setSecretWord] = useState('react');
 const [guessedLetters, setGuessedLetters] = useState([]);
 const [input, setInput] = useState('');
 const [status, setStatus] = useState('playing');

 // Handle User Guess
 const handleGuess = (e) => {
   e.preventDefault();
   if (!input || input.length !== 1 || guessedLetters.includes(input)) return;

   setGuessedLetters([...guessedLetters, input]);
   setInput('');

   // Check if the game is won
   const allGuessed = secretWord.split('').every(letter => guessedLetters.includes(letter) || letter === input);
   if (allGuessed) setStatus('won');
 };

 // Display Word
 const displayWord = secretWord.split('').map((letter, index) => (
   <span key={index} className="letter">
     {guessedLetters.includes(letter) ? letter : '_'}
   </span>
 ));

  return (
    <div className="App">
      <h1>Word Guessing Game</h1>
      <div className="word-display">
        {displayWord}
      </div>
      <form onSubmit={handleGuess} className="guess-form">
        <input 
          type="text" 
          value={input} 
          onChange={(e) => setInput(e.target.value)}
          maxLength="1"
          className="guess-input"
        />
        <button type="submit" className="guess-button">Guess</button>
      </form>
      {status === 'won' && <p className="status-message">Congratulations, you won!</p>}
    </div>
  );
}

export default Games2;
