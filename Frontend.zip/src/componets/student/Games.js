import React, { useState, useEffect } from "react";
import Footer from '../inc/footer.js'
import Header from '../inc/header.js'
import Navbar from '../inc/Navbar.js'
import "./Games.css";

const Games = () => {
  const [num1, setNum1] = useState(0);
  const [num2, setNum2] = useState(0);
  const [userAnswer, setUserAnswer] = useState("");
  const [message, setMessage] = useState("");
  const [sum, setSum] = useState(0);

  // Initialize the game with random numbers
  useEffect(() => {
    generateNumbers();
  }, []);

  const generateNumbers = () => {
    const n1 = Math.floor(Math.random() * 20 + 1);
    const n2 = Math.floor(Math.random() * 20 + 1);
    setNum1(n1);
    setNum2(n2);
    setSum(n1 + n2);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (parseInt(userAnswer) === sum) {
      setMessage("Well Done! Your Answer is Correct");
    } else {
      setMessage(`Correct Answer is ${sum}. Please Try Again`);
    }
    setUserAnswer("");
    generateNumbers();
  };

  return (
    <div className="layout-wrapper layout-content-navbar">
      <div className="layout-container">
        <Navbar />
        <div className="layout-page">
          <Header />
          <div className="container-xxl flex-grow-1 container-p-y">
            <div className="row">
              <div className="col-lg-11 mb-4 order-0">
                <div className="main-container">
                  <div className="main">
                    <h1>Math Addition <span> Quiz Game :)</span></h1>
                    <div className="main-box">
                      <div className="show-answer bg-danger py-2 text-center text-white w-100" >
                        <span id="ans">{message}</span>
                      </div>
                      <div className="box1 mt-5">
                        <div className="box-col">
                          <input type="text" value={num1} readOnly className="intext11" />
                        </div>
                        <div className="add-s">
                          <p>+</p>
                        </div>
                        <div className="box-col">
                          <input type="text" value={num2} readOnly className="intext11" />
                        </div>
                      </div>
                      <form onSubmit={handleSubmit}>
                        <div className="box2">
                          <input
                            type="text"
                            placeholder="Enter Answer"
                            value={userAnswer}
                            onChange={(e) => setUserAnswer(e.target.value)}
                            id="intext2"
                          />
                        </div>
                        <div className="box2 w-100">
                          <button className="btn w-100" type="submit">Check Answer</button>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <Footer />
        </div>
      </div>
    </div>
  );
};

export default Games;
